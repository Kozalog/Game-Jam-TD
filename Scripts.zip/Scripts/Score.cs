using UnityEngine;

public class Score
{
       public static int foodScore;
}
