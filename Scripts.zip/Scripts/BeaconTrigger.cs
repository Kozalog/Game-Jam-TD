using UnityEngine;

public class BeaconTrigger : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject winMenu;
    private PauseMenu pauseMenu;
    void OnTriggerEnter(Collider other)
    {
        pauseMenu = GameObject.Find("PauseMenu").GetComponent<PauseMenu>();   
        pauseMenu.menuRestartActive = true;
        winMenu.SetActive(true);
    }
}
