using System.Collections;
using UnityEngine;

public class DoorInteraction : MonoBehaviour
{
    [SerializeField] private float openAngle = 90f; 
    [SerializeField] private float openSpeed = 2f; 
    [SerializeField] private bool isOpen = false; 
    [SerializeField] private PlayerMovement _playerMovement; 
    [SerializeField] private Transform train; 

    private Quaternion _closedRotation; 
    private Quaternion _openRotation; 
    private Coroutine _currentCoroutine;

    void Start()
    {
        if (train == null)
        {
            train = GameObject.Find("TrainContainer")?.transform ?? GameObject.Find("Train")?.transform;
            if (train == null) Debug.LogError("Train or TrainContainer not found!");
        }
        transform.SetParent(train);

        _closedRotation = transform.localRotation;
        _openRotation = Quaternion.Euler(transform.localEulerAngles + new Vector3(0, openAngle, 0));

        if (_playerMovement == null)
        {
            Debug.LogError("PlayerMovement script not found in the scene!");
        }
    }

    void Update()
    {
        if (_playerMovement != null && _playerMovement.GetHighlight() == transform && Input.GetKeyDown(KeyCode.E))
        {
            if (_currentCoroutine != null) StopCoroutine(_currentCoroutine);
            _currentCoroutine = StartCoroutine(ToggleDoor());
        }
    }

    private IEnumerator ToggleDoor()
    {
        Quaternion targetRotation = isOpen ? _closedRotation : _openRotation;
        isOpen = !isOpen;

        while (Quaternion.Angle(transform.localRotation, targetRotation) > 0.01f)
        {
            transform.localRotation = Quaternion.Lerp(transform.localRotation, targetRotation, Time.deltaTime * openSpeed);
            yield return null;
        }
        transform.localRotation = targetRotation;
    }
}
