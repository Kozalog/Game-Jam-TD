using UnityEngine;

public class TrainAttach : MonoBehaviour
{

    [SerializeField] Transform platform;
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) 
        {
            Debug.Log("did it work");
            other.gameObject.transform.parent = platform; 
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            other.gameObject.transform.parent = null; 
        }
    }
}
