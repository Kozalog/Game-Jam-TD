using System.Globalization;
using UnityEngine;

public class FoodTrigger : MonoBehaviour
{

    private FoodShow foodShow;
    private FoodSpawn foodSpawn;

    public string FoodName;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        foodShow = GameObject.Find("FoodShow").GetComponent<FoodShow>();
        foodSpawn = GameObject.Find("FoodItems").GetComponentInChildren<FoodSpawn>();
        FoodName = foodShow.CheckFoodName;
    }

    // Update is called once per frame
    void OnTriggerEnter(Collider other)
    {

        if (other.CompareTag("Interactable"))
        {
            string otherName = other.gameObject.name.Replace("(Clone)", "");
            if (otherName == foodShow.CheckFoodName)
            {

                Destroy(other.gameObject);
                if (foodSpawn != null)
                {
                    foodSpawn.OnFoodDestroyed(other.gameObject);
                }
            }
        }
    }

    void Update()
    {
        FoodName = foodShow.CheckFoodName;
    }

}
