using UnityEngine;

public class FoodShow1 : MonoBehaviour
{

    public GameObject Banana;
    public GameObject Hamburger;
    public GameObject Hotdog;
    public GameObject Cheese;

    public GameObject SpawnSpace;

    public GameObject CheckFood { get; private set; }
    public string CheckFoodName { get; private set; }

    private Transform train;

    private FoodTrigger1 foodTrigger1;
    private int number;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        train = GameObject.Find("Train").transform;
        foodTrigger1 = GameObject.Find("TableObject (1)").GetComponentInChildren<FoodTrigger1>();
        number = Random.Range(1, 5);
        switch (number)
        {
            case 1:
                CheckFood = Instantiate(Banana, SpawnSpace.transform.position, Quaternion.identity);
                CheckFoodName = Banana.name;
                break;
            case 2:
                CheckFood = Instantiate(Hamburger, SpawnSpace.transform.position, Quaternion.identity);
                CheckFoodName = Hamburger.name;
                break;
            case 3:
                CheckFood = Instantiate(Hotdog, SpawnSpace.transform.position, Quaternion.identity);
                CheckFoodName = Hotdog.name;
                break;
            case 4:
                CheckFood = Instantiate(Cheese, SpawnSpace.transform.position, Quaternion.identity);
                CheckFoodName = Cheese.name;
                break;
        }
        CheckFood.transform.SetParent(train);

    }



    // Update is called once per frame

}
