using System.Globalization;
using UnityEngine;

public class FoodTrigger1 : MonoBehaviour
{

    private FoodShow1 foodShow1;
    private FoodSpawn foodSpawn;

    public string FoodName;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        foodShow1 = GameObject.Find("FoodShow (1)").GetComponent<FoodShow1>();
        foodSpawn = GameObject.Find("FoodItems").GetComponentInChildren<FoodSpawn>();
        FoodName = foodShow1.CheckFoodName;
    }

    // Update is called once per frame
    void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.name + "Other name");
        Debug.Log(foodShow1.CheckFoodName + "foodshow name");

        if (other.CompareTag("Interactable"))
        {
            string otherName = other.gameObject.name.Replace("(Clone)", "");
            if (otherName == foodShow1.CheckFoodName)
            {

                Destroy(other.gameObject);
                if (foodSpawn != null)
                {
                    foodSpawn.OnFoodDestroyed(other.gameObject);
                }
                Destroy(other.gameObject);
                
            }
        }
    }

    void Update()
    {
        FoodName = foodShow1.CheckFoodName;
    }

}
