using UnityEngine;

public class FoodSpawn : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is create

    public GameObject SpawnSpace;
    public GameObject Food;
    public int foodNumber;
    private Transform train;


    public GameObject Banana;
    public GameObject Hamburger;
    public GameObject Hotdog;
    public GameObject Cheese;

    private GameObject bananaInstance;
    private GameObject hamburgerInstance;
    private GameObject hotdogInstance;
    private GameObject cheeseInstance;
    private int number;


    void Start()
    {
        train = GameObject.Find("Train").transform;

        SpawnFood(ref bananaInstance, Banana);
        SpawnFood(ref hamburgerInstance, Hamburger);
        SpawnFood(ref hotdogInstance, Hotdog);
        SpawnFood(ref cheeseInstance, Cheese);
    }
    public void SpawnFood(ref GameObject foodInstance, GameObject foodPrefab)
    {
        if (foodInstance == null)
        {
            foodInstance = Instantiate(foodPrefab, SpawnSpace.transform.position, Quaternion.identity);
            foodInstance.transform.SetParent(train);
            foodInstance.tag = "Interactable";
        }
    }

    void Update()
    {
        SpawnFood(ref bananaInstance, Banana);
        SpawnFood(ref hamburgerInstance, Hamburger);
        SpawnFood(ref hotdogInstance, Hotdog);
        SpawnFood(ref cheeseInstance, Cheese);
    }

    public void OnFoodDestroyed(GameObject food)
    {
        {
            if (food == bananaInstance)
                bananaInstance = null;
            else if (food == hamburgerInstance)
                hamburgerInstance = null;
            else if (food == hotdogInstance)
                hotdogInstance = null;
            else if (food == cheeseInstance)
                cheeseInstance = null;
        }
        Score.foodScore += 1;
    }
        
}

