using System.Globalization;
using UnityEngine;

public class FoodTrigger2 : MonoBehaviour
{

    private FoodShow2 foodShow2;
    private FoodSpawn foodSpawn;

    public string FoodName;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        foodShow2 = GameObject.Find("FoodShow (2)").GetComponent<FoodShow2>();
        foodSpawn = GameObject.Find("FoodItems").GetComponentInChildren<FoodSpawn>();
        FoodName = foodShow2.CheckFoodName;
    }

    // Update is called once per frame
    void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.name + "Other name");
        Debug.Log(foodShow2.CheckFoodName + "foodshow name");

        if (other.CompareTag("Interactable"))
        {
            string otherName = other.gameObject.name.Replace("(Clone)", "");
            if (otherName == foodShow2.CheckFoodName)
            {

                Destroy(other.gameObject);
                if (foodSpawn != null)
                {
                    foodSpawn.OnFoodDestroyed(other.gameObject);
                }
            }
        }
    }

    void Update()
    {
        FoodName = foodShow2.CheckFoodName;
    }

}
