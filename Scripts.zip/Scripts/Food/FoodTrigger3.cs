using System.Globalization;
using UnityEngine;

public class FoodTrigger3 : MonoBehaviour
{

    private FoodShow3 foodShow3;
    private FoodSpawn foodSpawn;

    public string FoodName;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        foodShow3 = GameObject.Find("FoodShow (3)").GetComponent<FoodShow3>();
        foodSpawn = GameObject.Find("FoodItems").GetComponentInChildren<FoodSpawn>();
        FoodName = foodShow3.CheckFoodName;
    }

    // Update is called once per frame
    void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.name + "Other name");
        Debug.Log(foodShow3.CheckFoodName + "foodshow name");

        if (other.CompareTag("Interactable"))
        {
            string otherName = other.gameObject.name.Replace("(Clone)", "");
            if (otherName == foodShow3.CheckFoodName)
            {

                Destroy(other.gameObject);
                if (foodSpawn != null)
                {
                    foodSpawn.OnFoodDestroyed(other.gameObject);
                }
            }
        }
    }

    void Update()
    {
        FoodName = foodShow3.CheckFoodName;
    }

}
