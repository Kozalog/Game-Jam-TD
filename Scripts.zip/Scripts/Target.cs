using UnityEngine;

public class Target : MonoBehaviour
{
    public float health = 50f;
    private HoldableItems holdableItems;
    public void TakeDamage(float amount)
    {
        health -= amount;
        holdableItems = GameObject.Find("holditem").GetComponent<HoldableItems>();
        holdableItems.coalItem.SetActive(true);
        if (health <= 0f)
        {
            Die();
        }
    }

    public void GiveHealth(float amount)
    {
        health += amount;
        if (health <= 0f)
        {
            Die();
        }
    }

    void Die()
    {
        Destroy(gameObject);
    }
}
