using UnityEditor;
using UnityEngine;

public class PickUpScript : MonoBehaviour
{
    bool isHolding = false;

    [SerializeField]
    float throwForce = 600f;

    [SerializeField]
    float maxDistance = 3f;
    float distance;
    [SerializeField] private Transform train;
    TempParent tempParent;
    Rigidbody rb;

    Vector3 objectPos;

    private PlayerMovement _playerMovement;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        tempParent = TempParent.Instance;
        train = GameObject.Find("TrainContainer")?.transform ?? GameObject.Find("Train")?.transform;
        _playerMovement = GameObject.Find("Player").GetComponent<PlayerMovement>();
    }

    void Update()
    {
        if (isHolding)
        {
            Hold();
            if (_playerMovement.GetHighlight() != transform)
            {
                Drop();
            }
        }
        if (tempParent != null)
        {
            if (_playerMovement.GetHighlight() == transform && Input.GetKeyDown(KeyCode.E) && !isHolding)
            {
                distance = Vector3.Distance(this.transform.position, tempParent.transform.position);
                if (distance <= maxDistance)
                {
                    isHolding = true;
                    rb.useGravity = false;
                    rb.detectCollisions = true;
                    this.transform.SetParent(tempParent.transform);
                }
            }
            else if (Input.GetKeyDown(KeyCode.E) && isHolding)
            {
                Drop();
            }
        }
        else
        {
            Debug.Log("Temp parent none");
        }
    }

    private void OnMouseExit()
    {
        Drop();
    }

    private void Hold()
    {

        
        distance = Vector3.Distance(this.transform.position, tempParent.transform.position);

        if (distance >= maxDistance)
        {
            Drop();
        }

        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;        

        if (Input.GetMouseButtonDown(1))
        {
            rb.AddForce(tempParent.transform.forward * throwForce);
            Drop();
        }
    }

    private void Drop()
    {
        Debug.Log("Drop enter");
        if (isHolding)
        {
            Debug.Log("Drop enter2");
            isHolding = false;
            transform.SetParent(train);
            
            rb.useGravity = true;
        }
    }

}
