using UnityEngine;
using UnityEngine.EventSystems;

public class Interactable : MonoBehaviour
{



    public void Interact()
    {
        Debug.Log(gameObject.name + " was interacted with!");        
    }


    
}
