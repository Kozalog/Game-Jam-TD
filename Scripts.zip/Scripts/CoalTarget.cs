using UnityEngine;

public class CoalTarget : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public float health = 50f;
    private HoldableItems holdableItems;
    
    [SerializeField] private float healthReductionAmount = 5f; // Amount to reduce health by
    [SerializeField] private float healthReductionInterval = 1f; // Time interval in seconds
    [SerializeField] private float maxMoveDistance = 1f; // Max distance to move downward
    [SerializeField] private GameObject spriteObject;
    private float timer = 0f;
    private float initialY; // Starting Y position
    private float initialHealth; // Initial health for reference
    private SpriteRenderer spriteRenderer;

    public GameObject RestartMenu;

    private PauseMenu pauseMenu;
    void Start()
    {
        pauseMenu = GameObject.Find("PauseMenu").GetComponent<PauseMenu>();   
        initialY = spriteObject.transform.position.y;
        initialHealth = health;
    }

    void Update()
    {
        timer += Time.deltaTime;
        
        if (timer >= healthReductionInterval)
        {
            GiveHealth(-healthReductionAmount);
            timer = 0f; 
        }

        UpdatePosition();
    }

    public void GiveHealth(float amount)
    {
        health += amount;
        if (health <= 0f)
        {
            Die();
        }
    } 

    void UpdatePosition()
    {
        float healthRatio = health / initialHealth;
        
        float newY = initialY - (1f - healthRatio) * maxMoveDistance;
        
        spriteObject.transform.position = new Vector3(
            spriteObject.transform.position.x, 
            newY, 
            spriteObject.transform.position.z
        );
    }

    void Die()
    {
        Destroy(gameObject);
        pauseMenu.menuRestartActive = true;
        RestartMenu.SetActive(true);
    }
}
