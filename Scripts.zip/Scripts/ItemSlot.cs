using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.EventSystems;
public class ItemSlot : MonoBehaviour, IPointerClickHandler
{


    public string itemName;
    public int quantity;
    public Sprite itemSprite;
    public bool isFull;
    public string itemDescription;

    [SerializeField]
    private TMP_Text quantityText;

    [SerializeField]
    private Image itemImage;

    public Sprite emptySprite;
    public Image itemDescriptionImage;
    public TMP_Text ItemDescriptionNameText;
    public TMP_Text ItemDescriptionText;

    public GameObject selectedShader;
    public bool thisItemSelected;

    public GameObject emptyGameObject;

    private InventoryManager inventoryManager;
    private GameObject itemObject;

    public HoldableItems holdableItems;

    private Transform train;
    private void Start()
    {
        inventoryManager = GameObject.Find("InventoryCanvas").GetComponent<InventoryManager>();
        holdableItems = GameObject.Find("Player").GetComponentInChildren<HoldableItems>();
        train = GameObject.Find("TrainContainer")?.transform ?? GameObject.Find("Train")?.transform;
    }
    public void AddItem(string itemName, int quantity, Sprite itemSprite, string itemDescription, GameObject itemObject)
    {
        this.itemName = itemName;
        this.quantity = quantity;
        this.itemSprite = itemSprite;
        this.itemDescription = itemDescription;
        this.itemObject = itemObject;
        isFull = true;

        quantityText.text = quantity.ToString();
        quantityText.enabled = true;
        itemImage.sprite = itemSprite;
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            OnLeftClick();
        }
        if (eventData.button == PointerEventData.InputButton.Right)
        {
            OnRightClick();
        }
    }

    public void OnLeftClick()
    {
        if (thisItemSelected)
        {
            inventoryManager.UseItem(itemName);
            
            /*quantityText.text = this.quantity.ToString();
            if (this.quantity <= 0)
            {
                EmptySlot();
            }*/
        }
        else
        {
            inventoryManager.DeselectAllSlots();
            selectedShader.SetActive(true);
            thisItemSelected = true;
            ItemDescriptionNameText.text = itemName;
            ItemDescriptionText.text = itemDescription;
            itemDescriptionImage.sprite = itemSprite;
            if (itemDescriptionImage.sprite == null)
            {
                itemDescriptionImage.sprite = emptySprite;
            }
        }
        
    }

    private void EmptySlot()
    {

        Debug.Log("Entered");
        quantityText.enabled = false;
        itemImage.sprite = emptySprite;
        itemName = "";
        itemDescription = "";
        ItemDescriptionNameText.text = "";
        ItemDescriptionText.text = "";
        itemDescriptionImage.sprite = emptySprite;
        itemObject = emptyGameObject;
        holdableItems.test = false;
        thisItemSelected = false;
        isFull = false;
    }

    public void OnRightClick()
    {
        Quaternion rotation = Quaternion.Euler(-80, 0, 0);
        GameObject itemToDrop = Instantiate(itemObject, GameObject.FindWithTag("Player").transform.position + new Vector3(0f, -1f, 0), rotation);
        Item newItem = itemToDrop.AddComponent<Item>();
        newItem.itemName = itemName;
        newItem.itemDescription = itemDescription;
        newItem.itemObject = itemObject;
        newItem.transform.SetParent(train);

        if (!itemToDrop.GetComponent<Collider>())
        {
            itemToDrop.AddComponent<BoxCollider>();
        }
        
        EmptySlot();
    }
}
