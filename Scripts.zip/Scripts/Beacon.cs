using UnityEngine;

public class Beacon : MonoBehaviour
{

    public GameObject beacon;
    public GameObject trigger;

    // Update is called once per frame
    void Update()
    {
        if (Score.foodScore >= 1)
        {
            beacon.SetActive(true);
            trigger.SetActive(true);
        }
    }

    
}
