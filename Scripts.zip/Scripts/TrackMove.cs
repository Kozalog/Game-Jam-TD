using Unity.Collections;
using UnityEngine;

public class TrackMove : MonoBehaviour
{
    public GameObject track;
    public float speed = 0.5f;
    public float targetX;

    public void Update()
    {
        targetX = track.transform.position.x + 1f;
        float currentX = track.transform.position.x;
        float newX = Mathf.Lerp(currentX, targetX, Time.deltaTime * speed);

        track.transform.position = new Vector3(newX, track.transform.position.y, track.transform.position.z);
    
        
    }
}
