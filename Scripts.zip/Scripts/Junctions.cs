using System.ComponentModel;
using UnityEngine;
using UnityEngine.Splines;
using Unity.Mathematics;
using System.Collections.Generic;
public class Junctions : MonoBehaviour
{
    [SerializeField] private SplineContainer rail;  
    [SerializeField] private List<int> rails;      
    [SerializeField] private int currentRail = 0;   

    private void OnTriggerEnter(Collider other)
    {
        var animate = other.GetComponent<SplineAnimate>();
        if (animate != null && Input.GetKey(KeyCode.Space))
        {
            if (currentRail >= 0 && currentRail < rails.Count)
            {
                int splineIndex = rails[currentRail];
                if (rail != null && splineIndex >= 0 && splineIndex < rail.Splines.Count)
                {
                    animate.Container = rail;                   
                }
            }
        }
    }
    
}

