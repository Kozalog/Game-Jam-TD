using UnityEngine;
public class TrainCoalDoor : MonoBehaviour
{
    public enum Axis { X, Z } 
    [SerializeField] private Axis moveAxis = Axis.X; 
    [SerializeField] private float moveDistance = 2f; 
    [SerializeField] private float moveSpeed = 2f;
    [SerializeField] private bool movePositive = true; 
    [SerializeField] private bool isOpen = false; 
    [SerializeField] private LeverInteraction leverInteraction; 
    [SerializeField] private Transform train; 

    private Vector3 _closedPosition; 
    private Vector3 _openPosition; 
    private Coroutine _currentCoroutine;
    private bool lastLeverState;

    void Start()
    {
        // Parent door to train
        if (train == null)
        {
            train = GameObject.Find("TrainContainer")?.transform ?? GameObject.Find("Train")?.transform;
            if (train == null) Debug.LogError("Train or TrainContainer not found!");
        }
        transform.SetParent(train);

        _closedPosition = transform.localPosition;

        Vector3 direction = moveAxis == Axis.X ? Vector3.right : Vector3.forward;
        if (!movePositive) direction = -direction;
        _openPosition = _closedPosition + direction * moveDistance;

        if (leverInteraction != null)
        {
            lastLeverState = leverInteraction.isUp;
        }
    }

    void Update()
    {
        if (leverInteraction != null)
        {
            bool currentLeverState = leverInteraction.isUp;
            if (currentLeverState != lastLeverState)
            {
                if (_currentCoroutine != null) StopCoroutine(_currentCoroutine);
                _currentCoroutine = StartCoroutine(ToggleDoor());
            }
            lastLeverState = currentLeverState;
        }
    }

    private System.Collections.IEnumerator ToggleDoor()
    {
        Vector3 targetPosition = isOpen ? _closedPosition : _openPosition;
        isOpen = !isOpen;

        while (Vector3.Distance(transform.localPosition, targetPosition) > 0.01f)
        {
            transform.localPosition = Vector3.Lerp(transform.localPosition, targetPosition, Time.deltaTime * moveSpeed);
            yield return null;
        }
        transform.localPosition = targetPosition; 
    }
}
