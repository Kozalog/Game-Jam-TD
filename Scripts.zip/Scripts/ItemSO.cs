using NUnit.Framework.Internal;
using UnityEngine;

[CreateAssetMenu]
public class ItemSO : ScriptableObject
{
    public string itemName;
    public StatToChange statToChange = new StatToChange();
    public int amountToChange;
    public AttributesToChange attributeToChange = new AttributesToChange();
    public bool amountToChangeAttribute;

    public GameObject blueprint;
    private HoldableItems holdableItems;

    public void UseItem()
    {
        if (attributeToChange == AttributesToChange.held)
        {
            holdableItems = GameObject.Find("holditem").GetComponent<HoldableItems>();
            holdableItems.test = true;
        }
    }
    
    public enum StatToChange
    {
        none,
        health
    };

    public enum AttributesToChange
    {
        none,
        health,
        held
    };
}
