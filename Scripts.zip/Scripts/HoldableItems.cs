using UnityEngine;

public class HoldableItems : MonoBehaviour
{
    public float range = 4f;
    public Camera mainCamera;

    public float damage = 10f;
    public GameObject item;
    public GameObject coalItem;
    public bool test;

    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            if (item.activeInHierarchy && !coalItem.activeInHierarchy)
            {
                Shoot();
            }
            else if (coalItem.activeInHierarchy)
            {
                Heal();
            }
        }
        if (test)
        {
            setItemOn();
        }
        else
        {
            setItemOff();
        }
    }

    public void setItemOn()
    {
        item.SetActive(true);
    }

    public void setItemOff()
    {
        item.SetActive(false);
    }

    void Shoot()
    {
        RaycastHit hit;
        if (Physics.Raycast(mainCamera.transform.position, mainCamera.transform.forward, out hit, range))
        {
            Debug.Log(hit.transform.name);

            Target target = hit.transform.GetComponent<Target>();
            if (target != null)
            {
                target.TakeDamage(damage);
            }
        }
    }

    void Heal()
    {
        RaycastHit hit;
        if (Physics.Raycast(mainCamera.transform.position, mainCamera.transform.forward, out hit, range))
        {
            Debug.Log(hit.transform.name);
            Target target = hit.transform.GetComponent<Target>();
            CoalTarget coalTarget = hit.transform.GetComponent<CoalTarget>();
            if (coalTarget != null)
            {
                coalTarget.GiveHealth(damage);
                coalItem.SetActive(false);
            }
            if (target != null)
            {
                target.GiveHealth(damage);
                coalItem.SetActive(false);
            }
        }
    }
}
