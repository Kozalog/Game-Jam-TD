using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
public class PauseMenu : MonoBehaviour
{
    public GameObject pauseMenu;
    private bool menuActivated;
    public bool menuRestartActive;
    public GameObject restartMenu;
    private PlayerMovement playerMovement;

    public TMP_Text number;

    void Start()
    {
        playerMovement = GameObject.Find("Player").GetComponent<PlayerMovement>();
    }

    void Update()
    {
        number.text = Score.foodScore.ToString();
        if (Input.GetKeyDown(KeyCode.Escape) && menuActivated)
        {
            Time.timeScale = 1;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            pauseMenu.SetActive(false);
            menuActivated = false;
            playerMovement.paused = true;
        }
        else if (Input.GetKeyDown(KeyCode.Escape) && !menuActivated)
        {
            playerMovement.paused = false;
            Time.timeScale = 0;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            pauseMenu.SetActive(true);
            menuActivated = true;
        }
        else if(menuRestartActive)
        {
            Debug.Log("RestartMenu");
            playerMovement.paused = false;
            Time.timeScale = 0;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        
        
    }
    public void playGame()
    {
        Time.timeScale = 1;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        pauseMenu.SetActive(false);
        menuActivated = false;
        playerMovement.paused = true;
    }

    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void quitGame()
    {
        Application.Quit();
    }
}
