using Unity.VisualScripting;
using UnityEngine;

public class Item : MonoBehaviour
{

    [SerializeField]
    public string itemName;

    [SerializeField]
    public int quantity;

    [SerializeField]
    public Sprite sprite;

    [TextArea]
    [SerializeField]
    public string itemDescription;

    public GameObject itemObject;

    private InventoryManager inventoryManager;

    private PlayerMovement _playerMovement;
    void Start()
    {
        _playerMovement = GameObject.Find("Player").GetComponent<PlayerMovement>();
        inventoryManager = GameObject.Find("InventoryCanvas").GetComponent<InventoryManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if (_playerMovement.GetHighlight() == transform && Input.GetKeyDown(KeyCode.E))
        {
            inventoryManager.AddItem(itemName, quantity, sprite, itemDescription, itemObject);
            Destroy(gameObject);
        }
    }
}
