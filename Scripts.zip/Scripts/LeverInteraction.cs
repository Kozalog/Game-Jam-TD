using UnityEngine;
using System.Collections;
public class LeverInteraction : MonoBehaviour
{
    [SerializeField] private float rotationAngle = 45f; 
    [SerializeField] private float moveDistance = 0.2f; 
    [SerializeField] private float animationSpeed = 2f; 
    [SerializeField] public bool isUp = true; 
    [SerializeField] private Transform train; 
    private PlayerMovement _playerMovement;
    private Vector3 _upPosition; 
    private Vector3 _downPosition; 
    private Quaternion _upRotation; 
    private Quaternion _downRotation; 
    private Coroutine _currentCoroutine;

    void Start()
    {
        if (train == null)
        {
            train = GameObject.Find("TrainContainer")?.transform ?? GameObject.Find("Train")?.transform;
            if (train == null) Debug.LogError("Train or TrainContainer not found!");
        }
        transform.SetParent(train);

        _upPosition = transform.localPosition;
        _upRotation = transform.localRotation;
        _downPosition = _upPosition + Vector3.down * moveDistance; 
        _downRotation = Quaternion.Euler(transform.localEulerAngles + new Vector3(0, 0, -rotationAngle));

        _playerMovement = GameObject.Find("Player").GetComponent<PlayerMovement>();
    }

    void Update()
    {
        if (_playerMovement != null && _playerMovement.GetHighlight() == transform && Input.GetKeyDown(KeyCode.E))
        {
            ToggleLever();
        }
    }

    public void ToggleLever()
    {
        if (_currentCoroutine != null) StopCoroutine(_currentCoroutine);
        _currentCoroutine = StartCoroutine(ToggleLeverCoroutine());
    }

    private IEnumerator ToggleLeverCoroutine()
    {
        Vector3 targetPosition = isUp ? _downPosition : _upPosition;
        Quaternion targetRotation = isUp ? _downRotation : _upRotation;
        isUp = !isUp;

        float elapsedTime = 0f;
        Vector3 startPosition = transform.localPosition;
        Quaternion startRotation = transform.localRotation;

        while (elapsedTime < 1f)
        {
            elapsedTime += Time.deltaTime * animationSpeed;
            float t = Mathf.Clamp01(elapsedTime);
            transform.localPosition = Vector3.Lerp(startPosition, targetPosition, t);
            transform.localRotation = Quaternion.Lerp(startRotation, targetRotation, t);
            yield return null;
        }

        transform.localPosition = targetPosition;
        transform.localRotation = targetRotation;
    }
}
