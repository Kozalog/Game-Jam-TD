﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class MouseLookPlayer : MonoBehaviour
{
    public float mouseSensitivity = 100f;
    public Transform playerBody; // The player GameObject (capsule) to rotate horizontally
    public Transform cameraTransform; // The camera to rotate vertically
    private float xRotation = 0f;
    private Vector2 lookInput;
    private bool toggleCursor; // For toggling cursor lock (e.g., with Escape)

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        // Mouse look
        float mouseX = lookInput.x * mouseSensitivity * Time.deltaTime;
        float mouseY = lookInput.y * mouseSensitivity * Time.deltaTime;

        xRotation -= mouseY; // Invert Y for natural look
        xRotation = Mathf.Clamp(xRotation, -90f, 90f); // Limit vertical rotation

        cameraTransform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
        playerBody.Rotate(Vector3.up * mouseX); // Rotate player horizontally

        // Toggle cursor lock (e.g., with Escape)
        if (toggleCursor)
        {
            Cursor.lockState = Cursor.lockState == CursorLockMode.Locked ? CursorLockMode.None : CursorLockMode.Locked;
            Cursor.visible = Cursor.lockState != CursorLockMode.Locked;
        }
    }

    // Input System callback for mouse look
    public void OnLook(InputAction.CallbackContext context)
    {
        lookInput = context.ReadValue<Vector2>();
        Debug.Log($"MouseLook Input: {lookInput}"); // Debug to confirm input
    }

    // Input System callback for toggling cursor (replacing Input.GetKeyDown)
    public void OnToggleCursor(InputAction.CallbackContext context)
    {
        toggleCursor = context.performed;
        Debug.Log($"Toggle Cursor: {toggleCursor}"); // Debug to confirm input
    }
}
